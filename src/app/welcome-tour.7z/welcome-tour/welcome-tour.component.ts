import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-tour',
  templateUrl: './welcome-tour.component.html',
  styleUrls: ['./welcome-tour.component.css']
})
export class WelcomeTourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


} 
